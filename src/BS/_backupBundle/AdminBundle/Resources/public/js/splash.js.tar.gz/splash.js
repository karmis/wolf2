(function($){

	var defaults = {
		image:'app/libs/img/282.gif',
		msg: 'Загрузка...',
		bgcolor: '#ccc',
		textcolor: '#000',
		zimage: '9999999999999',
		ztext:'999999999999999',
		zbg:'999999999999',
		bgopacity: '0.6',
		name: 'default',
		delay: 300,
		plusdelay: 0,
		position: 'fixed',
		mtop: 0,
		mleft: 0
	};


	var methods = {
		getSizeSplash: function(el){
			var width = el.width();
			var height = el.height();
			
			if(width > $(window).width()){
				width = $(window).width();
			}

			if(height > $(window).height()){
				height = $(window).height();
			}

			return {width: width, height: height};
		},
		show: function(el, params){
			if($('#splash-'+params.name).length){
				return;
			}

			var size = this.getSizeSplash(el);

			this.createSplash(el, params, size);
			var _this = this;
			$(window).resize(function(){
				if($('#splash-'+params.name).length){
					var size = _this.getSizeSplash(el);
					_this.resetSplash(el, params, size);
					return;
				}
			});
		},
		resetSplash: function(el, params, size){
			el.find('#splash-'+params.name).remove();
			this.createSplash(el, params, size);
		},
		createSplash: function(el, params, size){

			el.prepend('<div id="splash-'+params.name+'" class="splash"><div class="splash-image"><img src="'+ params.image +'" class="splash-image-item"></div><div class="splash-text">'+params.msg+'</div>');
			
			$('.splash#splash-'+params.name).css({
				'position': params.position,
				// 'top': '0px',
				// 'left': '0px',
				'min-width': size.width+'px',
				'min-height': size.height+'px',
				'background-color': params.bgcolor,
				'-ms-filter': "progid:DXImageTransform.Microsoft.Alpha(Opacity='" + params.bgopacity*100 + "')",
				'filter': 'alpha(opacity='+ params.bgopacity*100 +')',
				'-moz-opacity': params.bgopacity,
				'-khtml-opacity': params.bgopacity,
				'opacity': params.bgopacity,
				'z-index': params.zbg,
				'margin-top': params.mtop + 'px',
				'margin-left': params.mleft + 'px',
				'display':'none'
			});

			var imageItem = $('.splash#splash-'+params.name+' .splash-image .splash-image-item');

			$('#splash-'+params.name + ' .splash-text').css({
				'position': 'relative',
				'text-align': 'center',
				'top': size.height/2+'px',
				'margin-left':'-'+30+'px',
				'color':'#000',
				'margin-top':'45px'
			});

			// splash-image
			imageItem.css({
				'position': 'absolute',
				'left': '50%',
				'top': '50%',
				'margin-left': '-' + 49 + 'px',
				'margin-top': '-' + 32 + 'px'
			});

			$('.splash#splash-'+params.name).show(params.delay);

		},
		hide: function(el, params){
			if(!$('#splash-'+params.name).length){
				return;
			}
			$('.splash#splash-'+params.name).delay(params.plusdelay).hide(params.delay, function(){
				el.find('#splash-'+params.name).remove();
			});
		}
	};
 

    jQuery.fn.splash = function(method, params){
		if (methods[method])
		{
			var options = $.extend({}, defaults, params);
		    return methods[ method ](this, options);
		}
		else
		{
			$.error( 'Метод "' +  method + '" не найден в плагине jQuery.splash' );
		}
    };
    // в итоге, метод pluginName вернет текущий объект jQuery обратно
})(jQuery);